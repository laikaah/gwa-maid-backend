# gwa-maid-backend
The backend for gwa-maid-web. Built with the Flask framework for Python.
